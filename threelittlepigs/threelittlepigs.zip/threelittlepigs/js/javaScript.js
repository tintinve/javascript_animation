let p1 = document.querySelector("#piggy1");
let p2 = document.querySelector("#piggy2");
let p3 = document.querySelector("#piggy3");

function pageLoad(){
    console.log("function: pageLoad")
    console.log("TODO: pigsEnter");
    //done
    console.log("TODO: background sound");
    let bgsound = document.querySelector("#bgsound");
    //bgsound.play();
    p3.addEventListener('animationend', pigsHasEntered)
}

function pigsHasEntered(){
    console.log("function: pigsHasEntered")
    console.log("TODO: playoinksound");

    let oink = document.querySelector("#oink");
    oink.play();
    //oinkSoundComplete();
    oink.addEventListener('ended', oinkSoundComplete)
}

function oinkSoundComplete(){
    console.log("function: oinkSoundComplete")
    console.log("TODO: make pigs dance");
    p1.classList.add("dance");
    p2.classList.add("dance");
    p3.classList.add("dance");
    //danceAnimationDone();
    setTimeout(danceAnimationDone, 4000);
}

function danceAnimationDone(){
    console.log("function: danceAnimationDone")
    console.log("TODO: wolf enters");
}



pageLoad();
